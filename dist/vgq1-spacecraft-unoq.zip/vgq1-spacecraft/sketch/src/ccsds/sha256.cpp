#include "sha256.h"
#include <string.h>

namespace ccsds {

namespace {
const uint32_t K[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};

inline uint32_t ror(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }
}  // namespace

void Sha256::reset() {
  static const uint32_t H0[8] = {0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                                 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19};
  memcpy(h_, H0, sizeof h_);
  len_ = 0;
  total_ = 0;
}

void Sha256::block(const uint8_t* p) {
  uint32_t w[64];
  for (int i = 0; i < 16; ++i)
    w[i] = ((uint32_t)p[4 * i] << 24) | ((uint32_t)p[4 * i + 1] << 16) | ((uint32_t)p[4 * i + 2] << 8) | p[4 * i + 3];
  for (int i = 16; i < 64; ++i) {
    const uint32_t s0 = ror(w[i - 15], 7) ^ ror(w[i - 15], 18) ^ (w[i - 15] >> 3);
    const uint32_t s1 = ror(w[i - 2], 17) ^ ror(w[i - 2], 19) ^ (w[i - 2] >> 10);
    w[i] = w[i - 16] + s0 + w[i - 7] + s1;
  }
  uint32_t a = h_[0], b = h_[1], c = h_[2], d = h_[3], e = h_[4], f = h_[5], g = h_[6], h = h_[7];
  for (int i = 0; i < 64; ++i) {
    const uint32_t S1 = ror(e, 6) ^ ror(e, 11) ^ ror(e, 25);
    const uint32_t ch = (e & f) ^ (~e & g);
    const uint32_t t1 = h + S1 + ch + K[i] + w[i];
    const uint32_t S0 = ror(a, 2) ^ ror(a, 13) ^ ror(a, 22);
    const uint32_t mj = (a & b) ^ (a & c) ^ (b & c);
    const uint32_t t2 = S0 + mj;
    h = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
  }
  h_[0] += a; h_[1] += b; h_[2] += c; h_[3] += d; h_[4] += e; h_[5] += f; h_[6] += g; h_[7] += h;
}

void Sha256::update(const uint8_t* d, size_t n) {
  total_ += n;
  while (n) {
    const size_t take = (64 - len_ < n) ? 64 - len_ : n;
    memcpy(buf_ + len_, d, take);
    len_ += take; d += take; n -= take;
    if (len_ == 64) { block(buf_); len_ = 0; }
  }
}

void Sha256::final(uint8_t out[32]) {
  const uint64_t bits = total_ * 8;
  const uint8_t pad = 0x80;
  update(&pad, 1);
  const uint8_t zero = 0;
  while (len_ != 56) update(&zero, 1);
  uint8_t l[8];
  for (int i = 0; i < 8; ++i) l[i] = (uint8_t)(bits >> (56 - 8 * i));
  update(l, 8);
  for (int i = 0; i < 8; ++i) {
    out[4 * i] = (uint8_t)(h_[i] >> 24); out[4 * i + 1] = (uint8_t)(h_[i] >> 16);
    out[4 * i + 2] = (uint8_t)(h_[i] >> 8); out[4 * i + 3] = (uint8_t)h_[i];
  }
}

void hmac_sha256(const uint8_t* key, size_t key_len, const uint8_t* m1, size_t n1,
                 const uint8_t* m2, size_t n2, const uint8_t* m3, size_t n3, uint8_t out[32]) {
  uint8_t k0[64] = {0};
  if (key_len > 64) {
    Sha256 s; s.update(key, key_len); s.final(k0);
  } else {
    memcpy(k0, key, key_len);
  }
  uint8_t pad[64];
  for (int i = 0; i < 64; ++i) pad[i] = k0[i] ^ 0x36;
  Sha256 inner;
  inner.update(pad, 64);
  if (n1) inner.update(m1, n1);
  if (n2) inner.update(m2, n2);
  if (n3) inner.update(m3, n3);
  uint8_t ih[32];
  inner.final(ih);
  for (int i = 0; i < 64; ++i) pad[i] = k0[i] ^ 0x5c;
  Sha256 outer;
  outer.update(pad, 64);
  outer.update(ih, 32);
  outer.final(out);
}

bool ct_equal(const uint8_t* a, const uint8_t* b, size_t n) {
  uint8_t diff = 0;
  for (size_t i = 0; i < n; ++i) diff |= (uint8_t)(a[i] ^ b[i]);
  return diff == 0;
}

}  // namespace ccsds
