#if !defined(_RADIOLIB_USER_BUILD_OPTIONS_H)
#define _RADIOLIB_USER_BUILD_OPTIONS_H

// this file can be used to define any user build options
// most commonly, RADIOLIB_EXCLUDE_* macros
// or enabling debug output

//#define RADIOLIB_DEBUG_BASIC        (1)   // basic debugging (e.g. reporting GPIO timeouts or module not being found)
//#define RADIOLIB_DEBUG_PROTOCOL     (1)   // protocol information (e.g. LoRaWAN internal information)
//#define RADIOLIB_DEBUG_SPI          (1)   // verbose transcription of all SPI communication - produces large debug logs!
//#define RADIOLIB_VERBOSE_ASSERT     (1)   // verbose assertions - will print out file and line number on failure

// ---- VGQ patch: build options of the VGQ-1 / DSS-Q1 sketches ----------------------
// TypeDef.h includes this file before BuildOpt.h, and BuildOpt.h includes TypeDef.h
// first, so every library and sketch translation unit sees exactly these values
// (App Lab sketch profiles cannot pass -D flags). Never define RADIOLIB_* elsewhere.

// No heap after initialisation: Module SPI transfers use two stack arrays of
// RADIOLIB_STATIC_SPI_ARRAY_SIZE (268) octets instead of new[] / delete[] per command.
#define RADIOLIB_STATIC_ONLY              (1)

// Only the SX126x driver (with PhysicalLayer and utils) is used. Each exclusion is
// written exactly "(1)": BuildOpt.h re-defines RADIOLIB_EXCLUDE_STM32WLX as (1).
// RADIOLIB_EXCLUDE_SX126X must never be set. RADIOLIB_EXCLUDE_LORAWAN is deliberately
// NOT set: LoRaWANPacMan.cpp and LoRaWANPackageTS009.cpp test it on their first line,
// before any include has reached this file, so they would compile against excluded
// headers and fail; unused LoRaWAN code is removed by the linker (--gc-sections).
#define RADIOLIB_EXCLUDE_CC1101           (1)
#define RADIOLIB_EXCLUDE_NRF24            (1)
#define RADIOLIB_EXCLUDE_RF69             (1)
#define RADIOLIB_EXCLUDE_SX1231           (1)
#define RADIOLIB_EXCLUDE_SI443X           (1)
#define RADIOLIB_EXCLUDE_RFM2X            (1)
#define RADIOLIB_EXCLUDE_SX127X           (1)
#define RADIOLIB_EXCLUDE_STM32WLX         (1)
#define RADIOLIB_EXCLUDE_SX128X           (1)
#define RADIOLIB_EXCLUDE_LR11X0           (1)
#define RADIOLIB_EXCLUDE_LR2021           (1)
#define RADIOLIB_EXCLUDE_AFSK             (1)
#define RADIOLIB_EXCLUDE_AX25             (1)
#define RADIOLIB_EXCLUDE_HELLSCHREIBER    (1)
#define RADIOLIB_EXCLUDE_MORSE            (1)
#define RADIOLIB_EXCLUDE_RTTY             (1)
#define RADIOLIB_EXCLUDE_SSTV             (1)
#define RADIOLIB_EXCLUDE_DIRECT_RECEIVE   (1)
#define RADIOLIB_EXCLUDE_BELL             (1)
#define RADIOLIB_EXCLUDE_APRS             (1)
#define RADIOLIB_EXCLUDE_FSK4             (1)
#define RADIOLIB_EXCLUDE_PAGER            (1)
#define RADIOLIB_EXCLUDE_ADSB             (1)

#endif
